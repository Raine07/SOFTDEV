<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['client_id'] = settings()->google_client_id;
$config['client_secret'] = settings()->google_client_secret;
