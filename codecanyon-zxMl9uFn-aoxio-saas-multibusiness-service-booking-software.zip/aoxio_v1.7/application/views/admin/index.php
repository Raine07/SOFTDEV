<?php include'include/header.php';?>
<?php include'include/left_sideber.php';?>
  <?php echo $main_content;?>
<?php include'include/footer.php';?>