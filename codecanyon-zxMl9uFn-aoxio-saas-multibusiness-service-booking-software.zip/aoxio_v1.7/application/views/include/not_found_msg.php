<div class="text-center mb-5 mb-md-7 mb-lg-9 minh-400">
    <h2 class="text-muted mt-6"><i class="lni lni-empty-file"></i></h2>
    <h4 class="pt-300 text-muted"><span><?php echo trans('no-data-found') ?></span></h4>
</div>